A Python Slugify application that handles Unicode


